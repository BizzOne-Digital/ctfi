import { Container } from "@/components/ui/Container";
import { Button } from "@/components/ui/Button";

export function CTABanner({
  heading,
  subheading,
  ctaText,
  ctaLink,
}: {
  heading?: string;
  subheading?: string;
  ctaText?: string;
  ctaLink?: string;
}) {
  return (
    <section className="bg-primary py-16 sm:py-20">
      <Container className="fade-up flex flex-col items-center gap-6 text-center">
        <h2 className="font-heading text-3xl font-semibold text-white sm:text-4xl">{heading}</h2>
        {subheading && <p className="max-w-xl text-white/90">{subheading}</p>}
        <Button href={ctaLink || "/book"} size="lg" variant="secondary" className="bg-white text-primary hover:bg-white/90">
          {ctaText || "Book Your Appointment"}
        </Button>
      </Container>
    </section>
  );
}
