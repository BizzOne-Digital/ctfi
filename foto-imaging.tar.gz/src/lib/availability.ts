import type { IAvailabilitySettings } from "@/models/AvailabilitySettings";
import type { IAppointment } from "@/models/Appointment";

function toMinutes(time: string) {
  const [h, m] = time.split(":").map(Number);
  return h * 60 + m;
}

function toTimeString(minutes: number) {
  const h = Math.floor(minutes / 60)
    .toString()
    .padStart(2, "0");
  const m = (minutes % 60).toString().padStart(2, "0");
  return `${h}:${m}`;
}

/**
 * Returns the list of bookable "HH:mm" start times for a given date, honoring
 * working days/hours, breaks, appointment duration + buffer, closed dates,
 * and existing (pending/approved) appointments on that date.
 */
export function getAvailableSlots(
  date: Date,
  settings: Pick<
    IAvailabilitySettings,
    | "workingDays"
    | "startTime"
    | "endTime"
    | "appointmentDurationMinutes"
    | "bufferMinutes"
    | "breaks"
    | "closedDates"
    | "bookingEnabled"
  >,
  existingAppointments: Pick<IAppointment, "preferredTime" | "status">[]
): string[] {
  if (!settings.bookingEnabled) return [];

  const dayOfWeek = date.getDay();
  if (!settings.workingDays.includes(dayOfWeek)) return [];

  const isClosed = settings.closedDates.some((closed) => {
    const c = new Date(closed);
    return (
      c.getFullYear() === date.getFullYear() &&
      c.getMonth() === date.getMonth() &&
      c.getDate() === date.getDate()
    );
  });
  if (isClosed) return [];

  const start = toMinutes(settings.startTime);
  const end = toMinutes(settings.endTime);
  const step = settings.appointmentDurationMinutes + settings.bufferMinutes;
  if (step <= 0 || end <= start) return [];

  const takenTimes = new Set(
    existingAppointments
      .filter((a) => a.status !== "rejected" && a.status !== "cancelled")
      .map((a) => a.preferredTime)
  );

  const slots: string[] = [];
  for (let t = start; t + settings.appointmentDurationMinutes <= end; t += step) {
    const inBreak = settings.breaks.some((brk) => {
      const bStart = toMinutes(brk.start);
      const bEnd = toMinutes(brk.end);
      return t < bEnd && t + settings.appointmentDurationMinutes > bStart;
    });
    if (inBreak) continue;

    const slot = toTimeString(t);
    if (takenTimes.has(slot)) continue;

    slots.push(slot);
  }

  return slots;
}

/** True if a chosen date is today or in the future (server-side sanity check). */
export function isFutureOrToday(dateStr: string) {
  const chosen = new Date(dateStr);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  chosen.setHours(0, 0, 0, 0);
  return chosen.getTime() >= today.getTime();
}
